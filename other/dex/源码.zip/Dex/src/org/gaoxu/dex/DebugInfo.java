package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import okio.BufferedSource;
import okio.Okio;

public class DebugInfo {
	public int line_start;
	public int parameters_size;
	public int[] parameter_names;

	@Override
	public String toString() {
		return "DebugInfo [\n\tline_start=" + line_start + ", \n\tparameters_size=" + parameters_size
				+ ", \n\tparameter_names=" + Arrays.toString(parameter_names) + "\n]";
	}

	public static DebugInfo parse(File DEX, int offset) throws IOException {
		BufferedSource source = Okio.buffer(Okio.source(DEX));
		source.skip(offset);
		
		DebugInfo debugInfo = new DebugInfo();
		debugInfo.line_start = Utils.readUnsignedLeb128(source);
		debugInfo.parameters_size = Utils.readUnsignedLeb128(source);
		debugInfo.parameter_names = new int[debugInfo.parameters_size];
		for (int i = 0; i < debugInfo.parameters_size; i++) {
			debugInfo.parameter_names[i] = Utils.readUnsignedLeb128(source) - 1;
		}
		return debugInfo;
	}

}
