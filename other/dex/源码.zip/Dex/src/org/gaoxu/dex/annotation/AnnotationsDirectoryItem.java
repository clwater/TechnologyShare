package org.gaoxu.dex.annotation;

import java.io.File;
import java.io.IOException;

import org.gaoxu.dex.DexClassDef;
import org.gaoxu.dex.DexFile;

import okio.BufferedSource;
import okio.Okio;

public class AnnotationsDirectoryItem {
	public int classAnnotationsOff;
	public int fieldsSize;
	public int methodsSize;
	public int parametersSize;

	public static AnnotationsDirectoryItem parse(File DEX, DexFile dexFile, DexClassDef def) throws IOException {
		AnnotationsDirectoryItem item = new AnnotationsDirectoryItem();
		BufferedSource source = Okio.buffer(Okio.source(DEX));
		source.skip(def.annotationsOff);
		item.classAnnotationsOff = source.readIntLe();
		item.fieldsSize = source.readIntLe();
		item.methodsSize = source.readIntLe();
		item.parametersSize = source.readIntLe();
		return item;
	}

	@Override
	public String toString() {
		return "AnnotationsDirectoryItem [\n\tclassAnnotationsOff=" + classAnnotationsOff + ", \n\tfieldsSize="
				+ fieldsSize + ", \n\tmethodsSize=" + methodsSize + ", \n\tparametersSize=" + parametersSize + "\n]";
	}

}
