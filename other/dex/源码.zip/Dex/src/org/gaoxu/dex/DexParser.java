package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.zip.Adler32;

import okio.Buffer;
import okio.BufferedSource;
import okio.Okio;

public class DexParser {
	private static final File DEX = new File("/Users/gaoxu/Downloads/dex/Hello.dex");
//	private static final File DEX = new File("/Users/gaoxu/Downloads/oa-base-159/classes.dex");
//	private static final File DEX = new File("/Users/gaoxu/workspace/android/oa/build/freeline/sdk/dex/classes.dex");

	public static void main(String[] args) {
		parseDex();
	}

	private static void parseDex() {
		try {
			DexFile dexFile = DexFile.parse(DEX);
			System.out.println(dexFile.toString());
			verifyCheckSum(DEX, dexFile);
			verifySignature(DEX, dexFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void verifyCheckSum(File DEX, DexFile dexFile) throws IOException {
		BufferedSource source = Okio.buffer(Okio.source(DEX));
		source.skip(8);// magic
		source.skip(4);// checksum
		Adler32 adler32 = new Adler32();
		adler32.update(source.readByteArray());
		Buffer buffer = new Buffer();
		buffer.writeIntLe((int) adler32.getValue());
		String checksum = buffer.readByteString().hex();
		buffer.close();
		System.out.println(checksum.equals(dexFile.dexHeader.checksum));
	}

	private static void verifySignature(File DEX, DexFile dexFile) throws IOException {
		BufferedSource source = Okio.buffer(Okio.source(DEX));
		source.skip(8);// magic
		source.skip(4);// checksum
		source.skip(20);// signature
		String signature = source.readByteString().sha1().hex();
		System.out.println(signature.equals(dexFile.dexHeader.signature));
	}
}
