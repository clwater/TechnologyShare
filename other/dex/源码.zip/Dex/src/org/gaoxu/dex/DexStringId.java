package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.BufferedSource;
import okio.Okio;

public class DexStringId {
	public int stringDataOff; // 4字节，当前String Item的offset

	public static ArrayList<DexStringId> parse(File DEX, DexHeader dexHeader) throws IOException {
		BufferedSource buffer = Okio.buffer(Okio.source(DEX));
		buffer.skip(dexHeader.stringIdsOff);
		int len = dexHeader.stringIdsSize;
		ArrayList<DexStringId> dexStringIds = new ArrayList<>(len);
		for (int i = 0; i < len; i++) {
			DexStringId dexStringId = new DexStringId();
			dexStringId.stringDataOff = buffer.readIntLe();
			dexStringIds.add(dexStringId);
		}
		return dexStringIds;
	}

	@Override
	public String toString() {
		return "DexStringId [\n\tstringDataOff=" + stringDataOff + "\n]";
	}
}
