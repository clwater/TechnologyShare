package org.gaoxu.dex;

public class DexClassDataHeader {
	public int staticFieldsSize;
	public int instanceFieldsSize;
	public int directMethodsSize;
	public int virtualMethodsSize;

	@Override
	public String toString() {
		return "DexClassDataHeader [\n\tstaticFieldsSize=" + staticFieldsSize + ", \n\tinstanceFieldsSize="
				+ instanceFieldsSize + ", \n\tdirectMethodsSize=" + directMethodsSize + ", \n\tvirtualMethodsSize="
				+ virtualMethodsSize + "\n]";
	}

}
