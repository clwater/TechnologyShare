package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.BufferedSource;
import okio.Okio;

public class DexMethodId {
	public short classIdx;
	public DexTypeId dexTypeId;
	public short protoIdx;
	public DexProtoId protoId;
	public int nameIdx;
	public String name;

	public static ArrayList<DexMethodId> parse(File DEX, DexFile dexFile) throws IOException {
		int len = dexFile.dexHeader.methodIdsSize;
		ArrayList<DexMethodId> dexMethodIds = new ArrayList<>(len);
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(dexFile.dexHeader.methodIdsOff);
		for (int i = 0; i < len; i++) {
			DexMethodId dexMethodId = new DexMethodId();
			dexMethodId.classIdx = bufferedSource.readShortLe();
			dexMethodId.dexTypeId = dexFile.dexTypeIds.get(dexMethodId.classIdx);
			dexMethodId.protoIdx = bufferedSource.readShortLe();
			dexMethodId.protoId = dexFile.dexProtoIds.get(dexMethodId.protoIdx);
			dexMethodId.nameIdx = bufferedSource.readIntLe();
			dexMethodId.name = dexFile.stringDataItems.get(dexMethodId.nameIdx).data;
			dexMethodIds.add(dexMethodId);
		}
		return dexMethodIds;
	}

	@Override
	public String toString() {
		return "DexMethodId [\n\tclassIdx=" + classIdx + ", \n\tdexTypeId=" + dexTypeId + ", \n\tprotoIdx=" + protoIdx
				+ ", \n\tprotoId=" + protoId + ", \n\tnameIdx=" + nameIdx + ", \n\tname=" + name + "\n]";
	}

}
