package org.gaoxu.dex;

public class DexMethod {
	public int methodIdx;
	public String methodName;
	public String accessFlags;
	public int codeOff;
	public DexCode dexCode;

	@Override
	public String toString() {
		return "DexMethod [\n\tmethodIdx=" + methodIdx + ", \n\tmethodName=" + methodName + ", \n\taccessFlags="
				+ accessFlags + ", \n\tcodeOff=" + codeOff + ", \n\tdexCode=" + dexCode + "\n]";
	}

}
