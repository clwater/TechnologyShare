package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.BufferedSource;
import okio.Okio;

public class DexTypeId {
	public int descriptorIdx; // 4字节，类型描述在stringIds中的角标
	public String desc;

	public static ArrayList<DexTypeId> parse(File DEX, DexFile dexFile) throws IOException {
		int len = dexFile.dexHeader.typeIdsSize;
		ArrayList<DexTypeId> dexTypeIds = new ArrayList<>(len);
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(dexFile.dexHeader.typeIdsOff);
		for (int i = 0; i < len; i++) {
			DexTypeId dexTypeId = new DexTypeId();
			dexTypeId.descriptorIdx = bufferedSource.readIntLe();
			dexTypeId.desc = dexFile.stringDataItems.get(dexTypeId.descriptorIdx).data;
			dexTypeIds.add(dexTypeId);
		}
		return dexTypeIds;
	}

	@Override
	public String toString() {
		return "DexTypeId [\n\tdescriptorIdx=" + descriptorIdx + ", \n\tdesc=" + desc + "\n]";
	}

}
