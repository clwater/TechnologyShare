package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import okio.BufferedSource;
import okio.Okio;

public class MapList {
	public int size;
	public MapItem[] list;

	public static MapList parse(File DEX, DexHeader dexHeader) throws IOException {
		MapList mapList = new MapList();
		BufferedSource source = Okio.buffer(Okio.source(DEX));
		source.skip(dexHeader.mapOff);
		mapList.size = source.readIntLe();
		mapList.list = new MapItem[mapList.size];
		for (int i = 0; i < mapList.size; i++) {
			MapItem mapItem = new MapItem();
			mapItem.type = Integer.toHexString(source.readShortLe());
			mapItem.unused = source.readShortLe();
			mapItem.size = source.readIntLe();
			mapItem.offset = source.readIntLe();
			mapList.list[i] = mapItem;
		}
		return mapList;
	}

	@Override
	public String toString() {
		return "MapList [\n\tsize=" + size + ", \n\tlist=" + Arrays.toString(list) + "\n]";
	}

}
