package org.gaoxu.dex;

import java.util.Arrays;

public class DexCode {
	public short registersSize;
	public short insSize;
	public short outsSize;
	public short triesSize;
	public int debugInfoOff;
	public int insnsSize;
	public short[] insns;
	public String[] insnsHex;
	public DebugInfo debugInfo;

	@Override
	public String toString() {
		return "DexCode [\n\tregistersSize=" + registersSize + ", \n\tinsSize=" + insSize + ", \n\toutsSize=" + outsSize
				+ ", \n\ttriesSize=" + triesSize + ", \n\tdebugInfoOff=" + debugInfoOff + ", \n\tinsnsSize=" + insnsSize
				+ ", \n\tinsns=" + Arrays.toString(insns) + ", \n\tinsnsHex=" + Arrays.toString(insnsHex)
				+ ", \n\tdebugInfo=" + debugInfo + "\n]";
	}

}
