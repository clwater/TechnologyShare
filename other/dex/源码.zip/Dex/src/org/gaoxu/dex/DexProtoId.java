package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.BufferedSource;
import okio.Okio;

public class DexProtoId {
	public int shortyIdx;
	public String shortyIdDesc;
	public int returnTypeIdx;
	public String returnType;
	public int parametersOff;
	public DexTypeList parameters;

	public static ArrayList<DexProtoId> parse(File DEX, DexFile dexFile) throws IOException {
		int len = dexFile.dexHeader.protoIdsSize;
		ArrayList<DexProtoId> dexProtoIds = new ArrayList<>(len);
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(dexFile.dexHeader.protoIdsOff);
		for (int i = 0; i < len; i++) {
			DexProtoId dexProtoId = new DexProtoId();
			dexProtoId.shortyIdx = bufferedSource.readIntLe();
			dexProtoId.shortyIdDesc = dexFile.stringDataItems.get(dexProtoId.shortyIdx).data;
			dexProtoId.returnTypeIdx = bufferedSource.readIntLe();
			dexProtoId.returnType = dexFile.dexTypeIds.get(dexProtoId.returnTypeIdx).desc;
			dexProtoId.parametersOff = bufferedSource.readIntLe();
			dexProtoIds.add(dexProtoId);
		}
		for (int i = 0; i < len; i++) {
			DexProtoId dexProtoId = dexProtoIds.get(i);
			if (dexProtoId.parametersOff > 0) {
				dexProtoId.parameters = DexTypeList.parse(DEX, dexFile, dexProtoId.parametersOff);
			}
		}
		return dexProtoIds;
	}

	@Override
	public String toString() {
		return "DexProtoId [\n\tshortyIdx=" + shortyIdx + ", \n\tshortyIdDesc=" + shortyIdDesc + ", \n\treturnTypeIdx="
				+ returnTypeIdx + ", \n\treturnType=" + returnType + ", \n\tparametersOff=" + parametersOff
				+ ", \n\tparameters=" + parameters + "\n]";
	}

}
