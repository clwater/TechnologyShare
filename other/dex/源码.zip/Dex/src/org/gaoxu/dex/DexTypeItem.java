package org.gaoxu.dex;

public class DexTypeItem {
	public short typeIdx; // 2字节， typeIds中的角标
	public String typeDesc;

	@Override
	public String toString() {
		return "DexTypeItem [\n\ttypeIdx=" + typeIdx + ", \n\ttypeDesc=" + typeDesc + "\n]";
	}

}
