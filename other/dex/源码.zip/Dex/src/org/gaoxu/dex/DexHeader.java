package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;

import okio.BufferedSource;
import okio.Okio;

public class DexHeader {
	public String magic; // 8字节魔术，内容是"dex\n" +
							// MagicVersion，后者一般是"035\0"，DexOpt后版本号是"036\0"，N以后是"037\0"
	public String checksum; // 4字节，除8字节魔术和4字节checksum外所有字节的adler32
	public String signature; // 20字节，除8字节魔术、4字节checksum和20字节的signature外所有字节的SHA-1
	public int fileSize; // 4字节，当前dex文件的总大小
	public int headerSize; // 4字节，dex文件Header部分的大小，也是下一个区的offset，固定为0x70，也就是112
	public String endianTag; // 4字节，大小端标记，dex使用小端标记，值为78563412
	public int linkSize; // 4字节，值为0，没用
	public int linkOff; // 4字节，值为0，没用
	public int mapOff; // 4字节，mapItem的offset
	public int stringIdsSize; // 4字节，stringId的数量
	public int stringIdsOff; // 4字节，stringId的offset
	public int typeIdsSize; // 4字节，typeId的数量
	public int typeIdsOff;
	public int protoIdsSize;
	public int protoIdsOff;
	public int fieldIdsSize;
	public int fieldIdsOff;
	public int methodIdsSize;
	public int methodIdsOff;
	public int classDefsSize;
	public int classDefsOff;
	public int dataSize;
	public int dataOff;

	public static DexHeader parse(File DEX) throws IOException {
		DexHeader dexHeader = new DexHeader();
		BufferedSource buffer = Okio.buffer(Okio.source(DEX));
		dexHeader.magic = Utils.readByteString(buffer, 8).utf8();
		dexHeader.checksum = Utils.readByteString(buffer, 4).hex();
		dexHeader.signature = Utils.readByteString(buffer, 20).hex();
		dexHeader.fileSize = buffer.readIntLe();
		dexHeader.headerSize = buffer.readIntLe();
		dexHeader.endianTag = Utils.readByteString(buffer, 4).hex();
		dexHeader.linkSize = buffer.readIntLe();
		dexHeader.linkOff = buffer.readIntLe();
		dexHeader.mapOff = buffer.readIntLe();
		dexHeader.stringIdsSize = buffer.readIntLe();
		dexHeader.stringIdsOff = buffer.readIntLe();
		dexHeader.typeIdsSize = buffer.readIntLe();
		dexHeader.typeIdsOff = buffer.readIntLe();
		dexHeader.protoIdsSize = buffer.readIntLe();
		dexHeader.protoIdsOff = buffer.readIntLe();
		dexHeader.fieldIdsSize = buffer.readIntLe();
		dexHeader.fieldIdsOff = buffer.readIntLe();
		dexHeader.methodIdsSize = buffer.readIntLe();
		dexHeader.methodIdsOff = buffer.readIntLe();
		dexHeader.classDefsSize = buffer.readIntLe();
		dexHeader.classDefsOff = buffer.readIntLe();
		dexHeader.dataSize = buffer.readIntLe();
		dexHeader.dataOff = buffer.readIntLe();
		return dexHeader;
	}

	@Override
	public String toString() {
		return "DexHeader [\n\tmagic=" + magic + ", \n\tchecksum=" + checksum + ", \n\tsignature=" + signature
				+ ", \n\tfileSize=" + fileSize + ", \n\theaderSize=" + headerSize + ", \n\tendianTag=" + endianTag
				+ ", \n\tlinkSize=" + linkSize + ", \n\tlinkOff=" + linkOff + ", \n\tmapOff=" + mapOff
				+ ", \n\tstringIdsSize=" + stringIdsSize + ", \n\tstringIdsOff=" + stringIdsOff + ", \n\ttypeIdsSize="
				+ typeIdsSize + ", \n\ttypeIdsOff=" + typeIdsOff + ", \n\tprotoIdsSize=" + protoIdsSize
				+ ", \n\tprotoIdsOff=" + protoIdsOff + ", \n\tfieldIdsSize=" + fieldIdsSize + ", \n\tfieldIdsOff="
				+ fieldIdsOff + ", \n\tmethodIdsSize=" + methodIdsSize + ", \n\tmethodIdsOff=" + methodIdsOff
				+ ", \n\tclassDefsSize=" + classDefsSize + ", \n\tclassDefsOff=" + classDefsOff + ", \n\tdataSize="
				+ dataSize + ", \n\tdataOff=" + dataOff + "\n]";
	}

}
