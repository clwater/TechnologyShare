package org.gaoxu.dex;

public class DexField {
	public int fieldIdx;
	public int accessFlags;

	@Override
	public String toString() {
		return "DexField [\n\tfieldIdx=" + fieldIdx + ", \n\taccessFlags=" + accessFlags + "\n]";
	}

}
