package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.BufferedSource;
import okio.Okio;

public class DexTypeList {
	public int size;
	public ArrayList<DexTypeItem> list;

	public static DexTypeList parse(File DEX, DexFile dexFile, long offset) throws IOException {
		DexTypeList dexTypeList = new DexTypeList();
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(offset);
		dexTypeList.size = bufferedSource.readIntLe();
		dexTypeList.list = new ArrayList<>(dexTypeList.size);
		for (int i = 0; i < dexTypeList.size; i++) {
			DexTypeItem dexTypeItem = new DexTypeItem();
			dexTypeItem.typeIdx = bufferedSource.readShortLe();
			dexTypeItem.typeDesc = dexFile.dexTypeIds.get(dexTypeItem.typeIdx).desc;
			dexTypeList.list.add(dexTypeItem);
		}
		return dexTypeList;
	}

	@Override
	public String toString() {
		return "DexTypeList [\n\tsize=" + size + ", \n\tlist=" + list + "\n]";
	}

}
