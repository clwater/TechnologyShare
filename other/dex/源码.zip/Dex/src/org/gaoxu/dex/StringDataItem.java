package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okio.BufferedSource;
import okio.Okio;

public class StringDataItem {
	public int utf16_size; // string的长度，实际类型是uleb128，
	public String data; // 格式为MUTF-8

	public static ArrayList<StringDataItem> parse(File DEX, List<DexStringId> dexStringIds) throws IOException {
		ArrayList<StringDataItem> stringDataItems = new ArrayList<>(dexStringIds.size());
		int len = dexStringIds.size();
		System.err.println("len " + len);
		for (int i = 0; i < len; i++) {
			BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
			bufferedSource.skip(dexStringIds.get(i).stringDataOff);
			StringDataItem stringDataItem = new StringDataItem();
			int leb128 = Utils.readUnsignedLeb128_4(bufferedSource);
			stringDataItem.utf16_size = leb128;
			stringDataItem.data = Utils.readByteString(bufferedSource, leb128).utf8();
			stringDataItems.add(stringDataItem);
		}
		return stringDataItems;
	}

	@Override
	public String toString() {
		return "StringDataItem [\n\tutf16_size=" + utf16_size + ", \n\tdata=" + data + "\n]";
	}

}
