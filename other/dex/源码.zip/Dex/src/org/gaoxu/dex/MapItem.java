package org.gaoxu.dex;

public class MapItem {
	public String type;
	public short unused;
	public int size;
	public int offset;

	@Override
	public String toString() {
		return "MapItem [\n\ttype=" + type + ", \n\tunused=" + unused + ", \n\tsize=" + size + ", \n\toffset=" + offset
				+ "\n]";
	}

}
