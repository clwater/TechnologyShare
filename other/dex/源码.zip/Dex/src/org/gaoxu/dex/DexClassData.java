package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.Buffer;
import okio.BufferedSource;
import okio.Okio;

public class DexClassData {
	public DexClassDataHeader header;
	public ArrayList<DexField> staticFields;
	public ArrayList<DexField> instanceFields;
	public ArrayList<DexMethod> directMethods;
	public ArrayList<DexMethod> virtualMethods;

	public static DexClassData parse(File DEX, DexFile dexFile, long offset) throws IOException {
		DexClassData classData = new DexClassData();
		BufferedSource source = Okio.buffer(Okio.source(DEX));
		source.skip(offset);

		DexClassDataHeader dataHeader = new DexClassDataHeader();
		dataHeader.staticFieldsSize = Utils.readUnsignedLeb128(source);
		dataHeader.instanceFieldsSize = Utils.readUnsignedLeb128(source);
		dataHeader.directMethodsSize = Utils.readUnsignedLeb128(source);
		dataHeader.virtualMethodsSize = Utils.readUnsignedLeb128(source);
		classData.header = dataHeader;

		int len = dataHeader.staticFieldsSize;
		ArrayList<DexField> dataStaticFields = new ArrayList<>(len);
		for (int i = 0; i < len; i++) {
			DexField dexField = new DexField();
			dexField.fieldIdx = Utils.readUnsignedLeb128(source);
			dexField.accessFlags = Utils.readUnsignedLeb128(source);
			dataStaticFields.add(dexField);
		}
		classData.staticFields = dataStaticFields;

		len = dataHeader.instanceFieldsSize;
		ArrayList<DexField> dataInstanceFields = new ArrayList<>(len);
		for (int i = 0; i < len; i++) {
			DexField dexField = new DexField();
			dexField.fieldIdx = Utils.readUnsignedLeb128(source);
			dexField.accessFlags = Utils.readUnsignedLeb128(source);
			dataInstanceFields.add(dexField);
		}
		classData.instanceFields = dataInstanceFields;

		len = dataHeader.directMethodsSize;
		ArrayList<DexMethod> dataDirectMethods = new ArrayList<>(len);
		for (int i = 0; i < len; i++) {
			DexMethod dexField = new DexMethod();
			dexField.methodIdx = Utils.readUnsignedLeb128(source);
			dexField.methodName = dexFile.dexMethodIds.get(dexField.methodIdx).name;
			dexField.accessFlags = Integer.toHexString(Utils.readUnsignedLeb128(source));
			dexField.codeOff = Utils.readUnsignedLeb128(source);
			dataDirectMethods.add(dexField);
		}
		classData.directMethods = dataDirectMethods;

		len = dataHeader.virtualMethodsSize;
		ArrayList<DexMethod> dataVirtualMethods = new ArrayList<>(len);
		for (int i = 0; i < len; i++) {
			DexMethod dexField = new DexMethod();
			dexField.methodIdx = Utils.readUnsignedLeb128(source);
			dexField.methodName = dexFile.dexMethodIds.get(dexField.methodIdx).name;
			dexField.accessFlags = Integer.toHexString(Utils.readUnsignedLeb128(source));
			dexField.codeOff = Utils.readUnsignedLeb128(source);
			dataVirtualMethods.add(dexField);
		}
		classData.virtualMethods = dataVirtualMethods;

		parseDexCode(classData.directMethods, DEX, dexFile);
		parseDexCode(classData.virtualMethods, DEX, dexFile);
		return classData;
	}

	private static void parseDexCode(ArrayList<DexMethod> dexMethods, File DEX, DexFile dexFile) throws IOException {
		if (dexMethods.isEmpty()) {
			return;
		}
		for (DexMethod dexMethod : dexMethods) {
			if (dexMethod.codeOff > 0) {
				BufferedSource source = Okio.buffer(Okio.source(DEX));
				source.skip(dexMethod.codeOff);
				DexCode dexCode = new DexCode();
				dexCode.registersSize = source.readShortLe();
				dexCode.insSize = source.readShortLe();
				dexCode.outsSize = source.readShortLe();
				dexCode.triesSize = source.readShortLe();
				dexCode.debugInfoOff = source.readIntLe();
				dexCode.insnsSize = source.readIntLe();
				dexCode.insns = new short[dexCode.insnsSize];
				dexCode.insnsHex = new String[dexCode.insnsSize];
				for (int i = 0; i < dexCode.insnsSize; i++) {
					short insnsSh = source.readShortLe();
					dexCode.insns[i] = insnsSh;
					Buffer buffer = new Buffer();
					buffer.writeShort(insnsSh);
					dexCode.insnsHex[i] = buffer.readByteString().hex();
					buffer.close();
				}
				dexCode.debugInfo = DebugInfo.parse(DEX, dexCode.debugInfoOff);
				dexMethod.dexCode = dexCode;
			}
		}
	}

	@Override
	public String toString() {
		return "DexClassData [\n\theader=" + header + ", \n\tstaticFields=" + staticFields + ", \n\tinstanceFields="
				+ instanceFields + ", \n\tdirectMethods=" + directMethods + ", \n\tvirtualMethods=" + virtualMethods
				+ "\n]";
	}

}
