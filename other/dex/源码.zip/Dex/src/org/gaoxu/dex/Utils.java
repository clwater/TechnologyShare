package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Adler32;

import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;

public class Utils {
	public static ByteString readByteString(BufferedSource buffer, long size) throws IOException {
		byte[] bytes = buffer.readByteArray(size);
		return ByteString.of(bytes);
	}

	public static int readUnsignedLeb128(BufferedSource bufferedSource) throws IOException {
		int result = byte2Int(bufferedSource.readByte());
		if (result > 0x7f) {
			byte cur = bufferedSource.readByte();
			int hold = byte2Int(cur);
			result = (result & 0x7f) | ((cur & 0x7f) << 7);
			if (hold > 0x7f) {
				cur = bufferedSource.readByte();
				result |= (cur & 0x7f) << 14;
				hold = byte2Int(cur);
				if (hold > 0x7f) {
					cur = bufferedSource.readByte();
					result |= (cur & 0x7f) << 21;
					hold = byte2Int(cur);
					if (hold > 0x7f) {
						cur = bufferedSource.readByte();
						result |= cur << 28;
					}
				}
			}
		}
		return result;
	}

	private static int byte2Int(byte b) {
		if (b < 0) {
			return 256 + b;
		}
		return b;
	}

	public static int readUnsignedLeb128_2(BufferedSource in) throws IOException {
		int result = 0;
		int cur;
		int count = 0;

		do {
			byte b = in.readByte();// 读取一个字节
			cur = b & 0xff; // 该字节与0b11111111进行与操作,得到的应该还是其本身,这一步操作是否必要? 为了对齐8位？
			result |= (cur & 0x7f) << (count * 7); // 该字节与0b0111111进行与操作,去除最高位,然后左移7*count位数,与result进行或运算连接,左移是因为是小端存储
			System.err.println("count : " + count + "b = " + b + " cur = " + cur + " result =  " + result);
			count++;
		} while (((cur & 0x80) == 0x80) && count < 5);// 与0b10000000,最高位是1并且小于5个字节则一直循环

		// 10000 0000 是非法的LEB128序列,0用00000000表示
		if ((cur & 0x80) == 0x80) {
			throw new RuntimeException("invalid LEB128 sequence");
		}

		return result;
	}

	public static int readUnsignedLeb128_3(BufferedSource in) throws IOException {
		List<Byte> byteAryList = new ArrayList<Byte>();
		byte bytes = in.readByte();
		byte highBit = (byte) (bytes & 0x80);
		byteAryList.add(bytes);
		while (highBit != 0) {
			bytes = in.readByte();
			highBit = (byte) (bytes & 0x80);
			byteAryList.add(bytes);
		}
		byte[] byteAry = new byte[byteAryList.size()];
		for (int j = 0; j < byteAryList.size(); j++) {
			byteAry[j] = byteAryList.get(j);
		}
		return decodeUleb128(byteAry);
	}

	public static int decodeUleb128(byte[] byteAry) {
		int index = 0, cur;
		int result = byteAry[index];
		index++;

		if (byteAry.length == 1) {
			return result;
		}

		if (byteAry.length == 2) {
			cur = byteAry[index];
			index++;
			result = (result & 0x7f) | ((cur & 0x7f) << 7);
			return result;
		}

		if (byteAry.length == 3) {
			cur = byteAry[index];
			index++;
			result |= (cur & 0x7f) << 14;
			return result;
		}

		if (byteAry.length == 4) {
			cur = byteAry[index];
			index++;
			result |= (cur & 0x7f) << 21;
			return result;
		}

		if (byteAry.length == 5) {
			cur = byteAry[index];
			index++;
			result |= cur << 28;
			return result;
		}

		return result;

	}

	public static int readSignedLeb128(BufferedSource in) throws IOException {
		int result = 0;
		int cur;
		int count = 0;
		int signBits = -1;
		do {
			cur = in.readByte() & 0xff;
			result |= (cur & 0x7f) << (count * 7);
			signBits <<= 7;
			count++;
		} while (((cur & 0x80) == 0x80) && count < 5);
		if ((cur & 0x80) == 0x80) {
			throw new RuntimeException("invalid LEB128 sequence");
		}
		// Sign extend if appropriate
		if (((signBits >> 1) & result) != 0) {
			result |= signBits;
		}
		return result;
	}

	public static int readUnsignedLeb128_4(BufferedSource in) throws IOException {
		int result = 0;
		int cur;
		int count = 0;
		do {
			cur = in.readByte() & 0xff;
			result |= (cur & 0x7f) << (count * 7);
			count++;
		} while (((cur & 0x80) == 0x80) && count < 5);
		if ((cur & 0x80) == 0x80) {
			throw new RuntimeException("invalid LEB128 sequence");
		}
		return result;
	}

	public static String calcSignature(File DEX) throws IOException {
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(8 + 4 + 20);

		ByteString byteString = bufferedSource.readByteString();
		return byteString.sha1().hex();
	}

	public static String calcCheckSum(File DEX) throws IOException {
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(8 + 4);

		Adler32 adler32 = new Adler32();
		adler32.update(bufferedSource.readByteArray());
		long value = adler32.getValue();
		Buffer buffer = new Buffer();
		buffer.writeIntLe((int) value);
		ByteString calc = buffer.readByteString();
		buffer.close();
		return calc.hex();
	}
}
