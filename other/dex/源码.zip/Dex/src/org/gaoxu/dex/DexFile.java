package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class DexFile {
	public DexHeader dexHeader;
	public ArrayList<DexStringId> dexStringIds;
	public ArrayList<StringDataItem> stringDataItems;
	public ArrayList<DexTypeId> dexTypeIds;
	public ArrayList<DexProtoId> dexProtoIds;
	public ArrayList<DexMethodId> dexMethodIds;
	public ArrayList<DexFieldId> dexFieldIds;
	public ArrayList<DexClassDef> dexClassDefs;
	public MapList mapList;

	@Override
	public String toString() {
		return "DexFile [\n\tdexHeader=" + dexHeader + ", \n\tdexStringIds=" + dexStringIds + ", \n\tstringDataItems="
				+ stringDataItems + ", \n\tdexTypeIds=" + dexTypeIds + ", \n\tdexProtoIds=" + dexProtoIds
				+ ", \n\tdexMethodIds=" + dexMethodIds + ", \n\tdexFieldIds=" + dexFieldIds + ", \n\tdexClassDefs="
				+ dexClassDefs + ", \n\tmapList=" + mapList + "\n]";
	}

	public static DexFile parse(File DEX) throws IOException {
		DexFile dexFile = new DexFile();
		dexFile.dexHeader = DexHeader.parse(DEX);
		dexFile.dexStringIds = DexStringId.parse(DEX, dexFile.dexHeader);
		dexFile.stringDataItems = StringDataItem.parse(DEX, dexFile.dexStringIds);
		dexFile.dexTypeIds = DexTypeId.parse(DEX, dexFile);
		dexFile.dexProtoIds = DexProtoId.parse(DEX, dexFile);
		dexFile.dexMethodIds = DexMethodId.parse(DEX, dexFile);
		dexFile.dexFieldIds = DexFieldId.parse(DEX, dexFile);
		dexFile.dexClassDefs = DexClassDef.parse(DEX, dexFile);
		dexFile.mapList = MapList.parse(DEX, dexFile.dexHeader);
		return dexFile;
	}

}
