package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import okio.BufferedSource;
import okio.Okio;

public class DexFieldId {
	public short classIdx;
	public DexTypeId difiningClass;
	public short typeIdx;
	public DexTypeId typeId;
	public int nameIdx;
	public String name;

	public static ArrayList<DexFieldId> parse(File DEX, DexFile dexFile) throws IOException {
		int len = dexFile.dexHeader.fieldIdsSize;
		ArrayList<DexFieldId> dexFieldIds = new ArrayList<>(len);

		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(dexFile.dexHeader.fieldIdsOff);

		for (int i = 0; i < len; i++) {
			DexFieldId dexFieldId = new DexFieldId();
			dexFieldId.classIdx = bufferedSource.readShortLe();
			dexFieldId.difiningClass = dexFile.dexTypeIds.get(dexFieldId.classIdx);
			dexFieldId.typeIdx = bufferedSource.readShortLe();
			dexFieldId.typeId = dexFile.dexTypeIds.get(dexFieldId.typeIdx);
			dexFieldId.nameIdx = bufferedSource.readIntLe();
			dexFieldId.name = dexFile.stringDataItems.get(dexFieldId.nameIdx).data;
			dexFieldIds.add(dexFieldId);
		}
		return dexFieldIds;
	}

	@Override
	public String toString() {
		return "DexFieldId [\n\tclassIdx=" + classIdx + ", \n\tdifiningClass=" + difiningClass + ", \n\ttypeIdx="
				+ typeIdx + ", \n\ttypeId=" + typeId + ", \n\tnameIdx=" + nameIdx + ", \n\tname=" + name + "\n]";
	}

}
