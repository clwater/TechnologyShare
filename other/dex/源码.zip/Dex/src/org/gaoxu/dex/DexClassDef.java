package org.gaoxu.dex;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.gaoxu.dex.annotation.AnnotationsDirectoryItem;

import okio.BufferedSource;
import okio.Okio;

public class DexClassDef {
	public int classIdx;
	public int accessFlags;
	public int superclassIdx;
	public int interfacesOff;
	public int sourceFileIdx;
	public int annotationsOff;
	public int classDataOff;
	public int staticValuesOff;
	public AnnotationsDirectoryItem annotationsDirectoryItem;
	public DexClassData dexClassData;

	@Override
	public String toString() {
		return "DexClassDef [\n\tclassIdx=" + classIdx + ", \n\taccessFlags=" + accessFlags + ", \n\tsuperclassIdx="
				+ superclassIdx + ", \n\tinterfacesOff=" + interfacesOff + ", \n\tsourceFileIdx=" + sourceFileIdx
				+ ", \n\tannotationsOff=" + annotationsOff + ", \n\tclassDataOff=" + classDataOff
				+ ", \n\tstaticValuesOff=" + staticValuesOff + ", \n\tannotationsDirectoryItem="
				+ annotationsDirectoryItem + ", \n\tdexClassData=" + dexClassData + "\n]";
	}

	public static ArrayList<DexClassDef> parse(File DEX, DexFile dexFile) throws IOException {
		int len = dexFile.dexHeader.classDefsSize;
		BufferedSource bufferedSource = Okio.buffer(Okio.source(DEX));
		bufferedSource.skip(dexFile.dexHeader.classDefsOff);
		ArrayList<DexClassDef> dexClassDefs = new ArrayList<>(len);
		for (int i = 0; i < len; i++) {
			DexClassDef dexClassDef = new DexClassDef();
			dexClassDef.classIdx = bufferedSource.readIntLe();
			dexClassDef.accessFlags = bufferedSource.readIntLe();
			dexClassDef.superclassIdx = bufferedSource.readIntLe();
			dexClassDef.interfacesOff = bufferedSource.readIntLe();
			dexClassDef.sourceFileIdx = bufferedSource.readIntLe();
			dexClassDef.annotationsOff = bufferedSource.readIntLe();
			dexClassDef.classDataOff = bufferedSource.readIntLe();
			dexClassDef.staticValuesOff = bufferedSource.readIntLe();
			if (dexClassDef.annotationsOff != 0) {
				dexClassDef.annotationsDirectoryItem = AnnotationsDirectoryItem.parse(DEX, dexFile, dexClassDef);
			}
			dexClassDef.dexClassData = DexClassData.parse(DEX, dexFile, dexClassDef.classDataOff);
			dexClassDefs.add(dexClassDef);
		}
		return dexClassDefs;
	}
}
