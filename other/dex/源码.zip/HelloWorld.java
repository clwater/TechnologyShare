public class HelloWorld {
  public static void main(String[] argc) {
    System.out.println("Hello, Dex!\n");
  }
}
